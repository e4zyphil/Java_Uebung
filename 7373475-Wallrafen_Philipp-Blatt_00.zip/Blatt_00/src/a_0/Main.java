package a_0;

public class Main {
    public static void main (String[] args) {

        System.out.println("H\n  a       W\n    l      e\n      l       l\n        o        t\n                    !");
    }
}
