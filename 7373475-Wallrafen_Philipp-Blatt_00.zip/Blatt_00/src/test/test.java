package test;
import java.util.Scanner;

public class test {
    public static void main(String[] args) {
        System.out.print("Sir, sind sie bereit? ");
        method1();
    }

    static void method1() {
        Scanner s = new Scanner(System.in);
        String antwort = s.nextLine();
        if (antwort.matches("(?i:y)|(?i:yes)|(?i:j)|(?i:ja)|(?i:jo)|(?i:auf gehts)")) {
            go();
        } else {
            int st = 0;
            st++;
            System.out.println("Okay, sagen Sie mir sobald Sie bereit sind.");
            System.out.println(st);
            method1();
        }
    }

    private static void go() {
        int n;
        System.out.print("Okay und los gehts!\nT - ");
        for (n = 10; n > 0; n--) {
            try {
                System.out.print(n + " ");
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (n < 2) {
                rocketstart();
            }
        }
    }

    private static void rocketstart() {
            System.out.println("\nhyhhhyhhhhyyyysyyyyyhhhddddmmmmNN````.``....hdyd ..`-+ydNNM: ....-sysooooososossyddhdddddddddddddddm\n" +
                    "yyyyyyyyyyyyyyyyyyyhhhdmdddhdmmNy`````.`...-hyhd ...`.../hN+ -..-:oys/o+++++oossyddddddddddddddddddd\n" +
                    "yyyyyysysyyyyyyhhyhhhddmdmdmmmm+......`....:yohd`......-`-om+:..--syo/++/++++++oyyyhhhdddddddddddddd\n" +
                    "ysyysysyyyyyyyyyyyyhddmdddmdmh:``..`````....+oyh`.........`:hmy//:hho/+++++++++o+oosyyhhhyyhhdddddmd\n" +
                    "sssssysyyyyyyyysyyyhddhhyydd/.``...`.`......ssyd`..--.:--:..-/hms:syyso+++++++++o++o+oossssydmddhhdh\n" +
                    "yysyyyssysyyyyyyyyhhysooohs.```.`.-````.`..`sood..`-//://:-.-../hdhyssysssso++++o++++++ooosyddddhhhs\n" +
                    "yyyyyyyyysssyyyyyysyo+/oy/``-/++o``.---:...-+s+y-`-o/+s++o/.-....-mds+oososso+++++++ooooooshdddddhys\n" +
                    "yyyyyyyyyyyyysyyso/osoho-.``-so+/ .ysss--`...o++:``...`.`...-..`` /No/o+ooosoo++++++++oososhddddhsss\n" +
                    "yyyyhyyhhyyysssso+++hy:``..`.yo-`-ho.o:````.`-//:`````````-.://+shhMh-+oo+oooo++++++o++oosyyhdhhyoss\n" +
                    "yyyyhhddhhyyooo+++/ys`.....``..`/h/-.o-````.``/o/-:ohdmmmmNmNmmdysssyo++o+sooo+++++++++ooshdddhyysss\n" +
                    "yyhhhhdhhhysoo+++:/d` ...-.---.sy--:-.`````..`:o/mNNmdhyo+/+d....-/oyo++o+oooo++o++++++osyhddhhyssss\n" +
                    "yhyhhyyhhys++/++/.ymyhhddmhNNNd+..---o-  `````-h:Nm/.```` .:m:oshdmyo+oo++ooooooo++oooyyhhdddhyyssss\n" +
                    "hhhhhyyyso+//////-/yyssso/s+od:`.sdo/N+/+sdhs..d-dm-`-:/sss/ohddhymmo/+oo++oooo+++oosyhddddhhyssssso\n" +
                    "hhdhhhyoo++/////+os+++//:.`yy.`/yo-:ymsNhsNNo..ysmm//o//++/:++yyyhhms:+++++ooooooooosyhhhyyyysssssso\n" +
                    "hddddds++++//::shyyyyyyys/.dd:+/..-+mo/y/sMmdhshMMm--/++++/`+ossysymo/+o+++oooooooooosyyysyyssssssss\n" +
                    "ddhhhyyso+/+::+ssyyyyysss+.Nd-.::y:+dhyo.mNmmNyMMMs./+//+///ssysyhhmy/++++ooooososssssssssyyyysyysso\n" +
                    "yyyyyyyyyssyo+sssssssssyssoys:---s+/shyh+/hysh/mNm/-::////--ossyyyhmo:+++oooooooossssssyyyyyyysyysso\n" +
                    "ssyyyyysyyyyyyysysssssssssos/::-/s+/..sy:-oooo---::/-:--::.`/osss+dds:++++oooooossssssssyysyyyssssos\n" +
                    "ysyssyssssssssssssssssssosso+///oyoo-`//````..-/::/:--..-.`:ss+++omNs+ooo+++++o+ooosyhyssssyyyssoooo\n" +
                    "ysssssssssssssssssssssssysssooooso+o/.`.` ` `-::-::::...-..:s.``.`.yh++++o++++++++++o/////++yyooooo+\n" +
                    "yyysssssyyssssssoosyssssssosoosyo+-:-.`.` ```.---://:.````-+-..----:sy+++++++++++++//:://:/+ooo+++//\n" +
                    "://osssysssyyssssooooooooo+oooos- `:/.` `  ``.`.:://:.``.`````` ```..:/++++//+/+/+++/:::+//o+++/////\n" +
                    "````:ysyyyyyssssooo++++++o++++o:..-.````   `````:o+--- ``  `       ```-////////+/++++/+//++++/////:/\n" +
                    "...`/:-syyyyssooo+++++++////++:`            ````.::://```            `-/////////+++++++++++///////:/\n" +
                    "..`.`.``ohsysyo+++++++////////-                `..-:+:..`             -////////+++/++///////////::::\n" +
                    "--.````-hyyyso++//////////////-   `          ` ````.:.`-.`            ://///////++/++/////////:::::/\n" +
                    "--.`-/osyssoo+////+////////////`              ```  ```.:-`            .////////+++/+//////:::::::::/\n" +
                    "-.`.shhyyo+//:++///+////+++//+:`   `         `````   `..`             `:////////+/////://::///://///\n" +
                    "-`-ohyh+-..```--.``/o+++/++///.   `         ````     `.-.              .////////+///+///////////////\n" +
                    ":-:/yoo.`......``..`...::/o/++.              `` ``   ` ``              .+////+//+//+////////////////\n" +
                    "/:-:+.```..........----.` s+o/`                 ````` ``               `//////+++//+//+//////////+++\n" +
                    "//:.`..``...--..-.--...`.``+o/               ` ````.-..`                +//+//+/+/++++++++//++++++++\n" +
                    "++/----...-::--.-----...``` `                `` ``.../-                 :///+/////+++++//+++++++++++\n" +
                    "//::::----::::::-..---...```                 `````...:`                  -+/+//+//++++++++++++++++++\n" +
                    "/:::::--------::--..-.....```                 ``..--.-`                  :////++++++++++++++++++++++\n" +
                    "/////:--------:::-....----```                  `...---.                  o////++++++++++++++++++++++\n" +
                    "/::::--::--::--:--.....-.--`                  ```.---:`                  /++++++++++++++++++++++++++\n" +
                    ":-:::::::::------......-..-.``                 ```.--:`                  `:+/+++++++++++++++++++++++\n" +
                    ":---:::::::::----..`.......`.`                  ```.--`                   ++++++++++++++++++oo++++++\n" +
                    "::::::::::--------...`.....``                  ``  `.                     ++++++++++++++++oo++oooooo\n" +
                    "::::--------------.`.``.```.``                 .`````                     :o+++++++++++++ooooooooooo\n" +
                    "::-----.....--..--.....`.`                     ``..:.                     .oo+o++++o+++ooooooooooooo\n" +
                    ":::-........-..--..-...``...`                `  ``-/.                      -oo+o+oooo++ooooooooooooo\n" +
                    "::::--......-.----.....```..`                    `..                       -oooo++o+o+o+oooooooooooo");
        }
    }
