package a_2;

public class Main {
    public static void main (String[] args) {

        System.out.println(args[0]);
        System.out.println(args[1]);
        System.out.println(args[2]);
        System.out.println(args[3]);
        System.out.println(args[4]);
        System.out.println(args[5]);
        System.out.println(args[6]);
        System.out.println(args[7]);
        System.out.println(args[8]);
        System.out.println(args[9]);
        System.out.println(args[10]);
        System.out.println(args[11]);
        System.out.println(args[12]);
        System.out.println(args[13]);
        System.out.println(args[14]);
        System.out.println(args[15]);
    }
}
