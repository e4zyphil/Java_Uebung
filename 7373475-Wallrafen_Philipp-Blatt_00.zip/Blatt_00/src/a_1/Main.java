package a_1;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        System.out.print("Wie ist dein Name? ");
        Scanner s = new Scanner(System.in);
        String zeile = s.nextLine();
        System.out.println("Hallo " + zeile + "!");
        s.close();
    }
}